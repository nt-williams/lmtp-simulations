.onAttach <- function(libname, pkgname) {
  packageStartupMessage("Major changes in lmtp 1.0.0. Consult NEWS.md for more information.")
}
